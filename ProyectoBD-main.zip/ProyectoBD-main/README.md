# Sistema Médico

Proyecto donde realizamos en equipo un sistema médico empleando las siguientes herramientas:

- MySQL
- Java

<div align="center">
  <img src="https://img.shields.io/badge/MySQL-4479A1?style=for-the-badge&logo=mysql&logoColor=white" alt="">
  <img src="https://img.shields.io/badge/JAVA-DB0F27?style=for-the-badge&logo=JAVA&logoColor=white" alt="">
</div>
<br>
Realizado para la materia de Desarrollo de Aplicaciones en Manejadores de Bases de Datos Relacionales, Facultad de Contaduría y Administración, UNAM.

Integrantes:

- Bautista Castillo Mildreth Stephanie
- Chávez García Monsserrath
- Díaz Silleros Fabián Josafat
- Flores Morán Iván
- Gómez Contreras Juan Miguel
- Morales Gónzalez Fernando
- Morales Rodríguez Sofía
- Ortiz López Hugo Enrique
- Romero Sepúlveda Sofía Joan
